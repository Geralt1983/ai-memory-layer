'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import type { UIMessage } from '@/lib/types'
import Markdown from './Markdown'

interface ChatRef { id: string; title: string; createdAt: string }

export default function ChatUI({ initialChats }: { initialChats: ChatRef[] }) {
  const [chats, setChats] = useState(initialChats)
  const [activeId, setActiveId] = useState<string | null>(chats[0]?.id ?? null)
  const [messages, setMessages] = useState<UIMessage[]>([])
  const [input, setInput] = useState('')
  const [system, setSystem] = useState('You are a helpful personal assistant.')
  const [model, setModel] = useState<string>(process.env.NEXT_PUBLIC_OPENAI_MODEL || 'gpt-4o-mini')
  const [streaming, setStreaming] = useState(false)
  // start from whatever layout's script set
  const [theme, setTheme] = useState<'light'|'dark'>(() =>
    typeof document !== 'undefined' && document.documentElement.classList.contains('dark') ? 'dark' : 'light'
  )
  const [editingIndex, setEditingIndex] = useState<number | null>(null)

  const listRef = useRef<HTMLDivElement>(null)
  const abortRef = useRef<AbortController | null>(null)

  useEffect(() => {
    // ensure state matches DOM on first mount
    const isDark = document.documentElement.classList.contains('dark')
    setTheme(isDark ? 'dark' : 'light')
  }, [])

  function toggleTheme() {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    const el = document.documentElement
    if (next === 'dark') el.classList.add('dark'); else el.classList.remove('dark')
    el.style.colorScheme = next
    try { localStorage.setItem('theme', next) } catch {}
  }

  // Load messages when active chat changes
  useEffect(() => {
    if (!activeId) return
    ;(async () => {
      const res = await fetch(`/api/chats/${activeId}`)
      const data = await res.json()
      setMessages(data.messages)
    })()
  }, [activeId])

  // Auto scroll to bottom while streaming or when new messages arrive
  useEffect(() => {
    if (!listRef.current) return
    listRef.current.scrollTop = listRef.current.scrollHeight
  }, [messages, streaming])

  async function createNewChat() {
    const res = await fetch('/api/chats', { method: 'POST' })
    const data = await res.json()
    setChats(prev => [data.chat, ...prev])
    setActiveId(data.chat.id)
    setMessages([])
  }

  async function deleteChat(id: string) {
    await fetch(`/api/chats/${id}`, { method: 'DELETE' })
    setChats(prev => prev.filter(c => c.id !== id))
    if (activeId === id) {
      setActiveId(chats.find(c => c.id !== id)?.id ?? null)
      setMessages([])
    }
  }

  async function renameActive() {
    if (!activeId) return
    const current = chats.find(c => c.id === activeId)?.title || 'Untitled'
    const title = prompt('Rename chat', current)
    if (!title) return
    await fetch(`/api/chats/${activeId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }) })
    const list = await fetch('/api/chats').then(r => r.json())
    setChats(list.chats)
  }

  async function refreshChats() {
    const list = await fetch('/api/chats').then(r => r.json())
    setChats(list.chats)
  }

  async function sendMessage(e?: React.FormEvent) {
    e?.preventDefault()
    if (streaming) return
    const content = editingIndex !== null ? messages[editingIndex].content : input
    if (!content?.trim()) return

    // If editing, truncate history up to the edited user message
    let payloadChatId = activeId
    let optimistic: UIMessage[] = []
    if (editingIndex !== null) {
      const before = messages.slice(0, editingIndex) // everything before edited user message
      optimistic = [...before, { role: 'user', content }, { role: 'assistant', content: '' }]
      setMessages(optimistic)
      setEditingIndex(null)
    } else {
      setInput('')
      optimistic = [...messages, { role: 'user', content }, { role: 'assistant', content: '' }]
      setMessages(optimistic)
    }

    setStreaming(true)
    abortRef.current = new AbortController()
    const res = await fetch('/api/chat', {
      method: 'POST',
      signal: abortRef.current.signal,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chatId: payloadChatId, content, system, model })
    })

    const reader = res.body!.getReader()
    const decoder = new TextDecoder()
    let acc = ''

    try {
      while (true) {
        const { value, done } = await reader.read()
        if (done) break
        acc += decoder.decode(value, { stream: true })
        setMessages(m => {
          const copy = m.slice()
          const last = copy[copy.length - 1]
          if (last?.role === 'assistant') last.content = acc
          return copy
        })
      }
    } catch {
      // aborted
    } finally {
      setStreaming(false)
      await refreshChats()
      if (!activeId) {
        const list = await fetch('/api/chats').then(r => r.json())
        setActiveId(list.chats[0]?.id ?? null)
      }
    }
  }

  function stopStreaming() {
    try { abortRef.current?.abort() } catch {}
    setStreaming(false)
  }

  function regenerate() {
    if (streaming || messages.length < 2) return
    // find last user message index
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === 'user') { setEditingIndex(i); setInput(messages[i].content); break }
    }
  }

  const title = useMemo(() => chats.find(c => c.id === activeId)?.title ?? 'New chat', [activeId, chats])

  // keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toLowerCase().includes('mac')
      const meta = isMac ? e.metaKey : e.ctrlKey
      if (meta && e.key.toLowerCase() === 'enter') { e.preventDefault(); sendMessage() }
      if (e.key === 'Escape' && streaming) { e.preventDefault(); stopStreaming() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [streaming, messages])

  return (
    <div className="grid h-screen grid-cols-[280px_1fr]">
      {/* Sidebar */}
      <aside className="border-r border-white/10 bg-card-light dark:bg-card-dark p-3 flex flex-col gap-3">
        <button onClick={createNewChat} className="w-full rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white py-2 text-sm shadow">
          + New chat
        </button>
        <div className="flex-1 overflow-auto space-y-1">
          {chats.map(c => (
            <div key={c.id} className={`group flex items-center justify-between gap-2 px-3 py-2 rounded-xl cursor-pointer ${activeId===c.id? 'bg-white/60 dark:bg-white/10' : 'hover:bg-white/50 dark:hover:bg-white/10'}`}
                 onClick={() => setActiveId(c.id)}>
              <span className="truncate text-sm">{c.title}</span>
              <div className="opacity-0 group-hover:opacity-100 flex items-center gap-2 text-xs">
                <button onClick={(e)=>{e.stopPropagation(); setActiveId(c.id); renameActive()}} className="text-gray-400 hover:text-gray-200">Rename</button>
                <button onClick={(e)=>{e.stopPropagation(); deleteChat(c.id)}} className="text-red-400 hover:text-red-300">Delete</button>
              </div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between text-xs opacity-80">
          <button onClick={toggleTheme} className="px-2 py-1 rounded-lg bg-white/60 dark:bg-white/10">
            <span suppressHydrationWarning>{theme === 'dark' ? 'Light' : 'Dark'}</span>
          </button>
          <a className="underline" href="https://platform.openai.com/" target="_blank" rel="noreferrer">OpenAI</a>
        </div>
      </aside>

      {/* Main */}
      <main className="flex flex-col h-screen">
        {/* Header */}
        <header className="border-b border-white/10 px-6 py-3 flex items-center gap-3 bg-bg-light/60 dark:bg-bg-dark/60 sticky top-0 backdrop-blur">
          <h1 className="text-lg font-semibold truncate">{title}</h1>
          <div className="ml-auto flex items-center gap-2 text-xs">
            <select value={model} onChange={e=>setModel(e.target.value)} className="rounded-lg bg-white/60 dark:bg-white/10 px-2 py-1">
              <option value="gpt-4o-mini">gpt-4o-mini</option>
              <option value="gpt-4o">gpt-4o</option>
            </select>
            <details>
              <summary className="cursor-pointer px-2 py-1 rounded-lg bg-white/60 dark:bg-white/10">Settings</summary>
              <div className="absolute right-4 mt-2 w-[480px] rounded-2xl border border-white/10 bg-card-light dark:bg-card-dark p-3 shadow-xl">
                <label className="text-xs opacity-70">System prompt</label>
                <textarea value={system} onChange={e=>setSystem(e.target.value)} className="w-full mt-1 h-32 rounded-xl bg-white/60 dark:bg-white/10 p-2" />
              </div>
            </details>
            <button onClick={stopStreaming} disabled={!streaming} className="rounded-lg px-2 py-1 bg-red-600/80 text-white disabled:opacity-50">Stop</button>
            <button onClick={regenerate} disabled={streaming || messages.length<2} className="rounded-lg px-2 py-1 bg-white/60 dark:bg-white/10">Regenerate</button>
          </div>
        </header>

        {/* Messages */}
        <div ref={listRef} className="flex-1 overflow-auto px-6">
          <div className="mx-auto max-w-3xl py-6 space-y-6">
            {messages.map((m,i)=> (
              <div key={i} className={`rounded-2xl p-4 ${m.role==='user' ? 'bg-white/70 dark:bg-white/10' : 'bg-white/5 border border-white/10'}`}>
                {m.role === 'assistant' ? (
                  <Markdown text={m.content} />
                ) : (
                  <div className="whitespace-pre-wrap">{m.content}</div>
                )}
                {m.role === 'user' && (() => {
                  // Find last user message index
                  for (let j = messages.length - 1; j >= 0; j--) {
                    if (messages[j].role === 'user') return i === j;
                  }
                  return false;
                })() && (
                  <div className="mt-2">
                    <button className="text-xs opacity-80 underline" onClick={()=>{ setEditingIndex(i); setInput(m.content); }}>
                      Edit and regenerate
                    </button>
                  </div>
                )}
              </div>
            ))}
            {streaming && <div className="animate-pulse text-sm opacity-80">Assistant is typing…</div>}
          </div>
        </div>

        {/* Composer */}
        <form onSubmit={sendMessage} className="border-t border-white/10 p-4">
          <div className="mx-auto max-w-3xl flex gap-2">
            <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Message" className="flex-1 rounded-2xl bg-white/70 dark:bg-white/10 px-4 py-3" />
            <button disabled={streaming || !input.trim()} className="rounded-2xl px-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50">Send</button>
          </div>
          <div className="mx-auto max-w-3xl mt-2 text-xs opacity-70">Cmd Enter to send. Esc to stop.</div>
        </form>
      </main>
    </div>
  )
}