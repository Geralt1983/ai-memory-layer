/**
 * Memory client for connecting to the Python memory API
 */

export interface MemorySearchRequest {
  query: string;
  limit?: number;
}

export interface Memory {
  content: string;
  relevance_score: number;
  timestamp?: string;
  metadata?: Record<string, any>;
  type?: string;
  role?: string;
}

export interface MemorySearchResponse {
  memories: Memory[];
  total: number;
}

export interface ChatMessage {
  role: string;
  content: string;
}

export interface ContextChatRequest {
  messages: ChatMessage[];
  use_memory?: boolean;
  memory_limit?: number;
  model?: string;
  temperature?: number;
  stream?: boolean;
}

export interface ContextChatResponse {
  response: string;
  context_used: string;
  memories_found: number;
  model: string;
}

export interface MemoryStats {
  available: boolean;
  total_memories?: number;
  memory_types?: Record<string, number>;
  engine_type?: string;
  error?: string;
}

export class MemoryClient {
  private baseUrl: string;

  constructor(baseUrl: string = 'http://localhost:8001') {
    this.baseUrl = baseUrl;
  }

  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/health`);
      const data = await response.json();
      return data.memory_available === true;
    } catch (error) {
      console.log('Memory API not available:', error);
      return false;
    }
  }

  async searchMemories(request: MemorySearchRequest): Promise<MemorySearchResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/memory/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error searching memories:', error);
      return { memories: [], total: 0 };
    }
  }

  async getStats(): Promise<MemoryStats> {
    try {
      const response = await fetch(`${this.baseUrl}/memory/stats`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Error getting memory stats:', error);
      return { available: false, error: 'Failed to connect to memory API' };
    }
  }

  async contextChat(request: ContextChatRequest): Promise<ContextChatResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/chat/context`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error in context chat:', error);
      throw error;
    }
  }

  async *contextChatStream(request: ContextChatRequest): AsyncGenerator<string, void, unknown> {
    try {
      const response = await fetch(`${this.baseUrl}/chat/context/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...request, stream: true }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('Failed to get response reader');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          
          let newlineIndex;
          while ((newlineIndex = buffer.indexOf('\n\n')) !== -1) {
            const line = buffer.slice(0, newlineIndex).trim();
            buffer = buffer.slice(newlineIndex + 2);

            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') {
                return;
              }
              
              try {
                const parsed = JSON.parse(data);
                if (parsed.token) {
                  yield parsed.token;
                }
              } catch (e) {
                // Ignore parsing errors for malformed chunks
              }
            }
          }
        }
      } finally {
        reader.releaseLock();
      }
    } catch (error) {
      console.error('Error in context chat stream:', error);
      throw error;
    }
  }
}

// Global memory client instance
let memoryClient: MemoryClient | null = null;

export function getMemoryClient(): MemoryClient {
  if (!memoryClient) {
    memoryClient = new MemoryClient();
  }
  return memoryClient;
}