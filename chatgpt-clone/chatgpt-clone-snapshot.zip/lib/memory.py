#!/usr/bin/env python3
"""
Memory layer integration for ChatGPT clone.
Connects to the AI Memory Layer system for context-aware responses.
"""

import sys
import os
from pathlib import Path
import json
from typing import List, Dict, Any, Optional

# Add parent directory to path to import memory layer
parent_dir = Path(__file__).parent.parent.parent
sys.path.insert(0, str(parent_dir))

try:
    # Import memory layer components
    from optimized_clean_loader import create_cleaned_chatgpt_engine
    from optimized_memory_loader import create_optimized_chatgpt_engine  
    from core.similarity_utils import create_search_optimized_engine
    from core.context_builder import ContextBuilder
    
    MEMORY_AVAILABLE = True
    print("✅ AI Memory Layer integration available")
except ImportError as e:
    print(f"⚠️ Memory layer not available: {e}")
    MEMORY_AVAILABLE = False

class MemoryIntegration:
    """Integration layer between ChatGPT clone and AI Memory Layer"""
    
    def __init__(self):
        self.memory_engine = None
        self.context_builder = None
        
        if MEMORY_AVAILABLE:
            self._initialize_memory_engine()
    
    def _initialize_memory_engine(self):
        """Initialize the memory engine with ChatGPT conversations"""
        try:
            # Try to load cleaned memories first
            cleaned_path = parent_dir / "data" / "chatgpt_memories_cleaned.json"
            if cleaned_path.exists():
                print("🧹 Loading cleaned ChatGPT memories...")
                self.memory_engine = create_cleaned_chatgpt_engine()
            else:
                print("📂 Loading original ChatGPT memories...")
                self.memory_engine = create_optimized_chatgpt_engine()
            
            # Enhance with relevance scoring
            self.memory_engine = create_search_optimized_engine(self.memory_engine, min_score=0.3)
            
            # Initialize context builder
            self.context_builder = ContextBuilder(max_context_length=4000)
            
            print(f"✅ Memory engine loaded with {len(self.memory_engine.memories):,} memories")
            
        except Exception as e:
            print(f"❌ Failed to initialize memory engine: {e}")
            self.memory_engine = None
            self.context_builder = None
    
    def search_memories(self, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search memories relevant to the query"""
        if not self.memory_engine:
            return []
        
        try:
            # Search for relevant memories
            results = self.memory_engine.search(query, k=limit)
            
            # Convert to JSON-serializable format
            memories = []
            for memory in results:
                memories.append({
                    "content": memory.content,
                    "relevance_score": getattr(memory, 'relevance_score', 0.0),
                    "timestamp": memory.timestamp.isoformat() if hasattr(memory, 'timestamp') else None,
                    "metadata": getattr(memory, 'metadata', {}),
                    "type": getattr(memory, 'type', 'history'),
                    "role": getattr(memory, 'role', 'user')
                })
            
            return memories
            
        except Exception as e:
            print(f"Error searching memories: {e}")
            return []
    
    def build_context(self, query: str, conversation_history: List[Dict[str, Any]] = None) -> str:
        """Build context from memories and conversation history"""
        if not self.memory_engine or not self.context_builder:
            return ""
        
        try:
            # Search for relevant memories
            relevant_memories = self.memory_engine.search(query, k=8)
            
            # Build context
            context = self.context_builder.build_context(
                query=query,
                memories=relevant_memories,
                conversation_history=conversation_history or []
            )
            
            return context
            
        except Exception as e:
            print(f"Error building context: {e}")
            return ""
    
    def add_conversation_to_memory(self, conversation: Dict[str, Any]) -> bool:
        """Add a conversation to the memory system"""
        if not self.memory_engine:
            return False
        
        try:
            # Convert conversation to memory format
            from core.memory_engine import Memory
            from datetime import datetime
            
            # Create memory from conversation
            content = f"User: {conversation.get('user_message', '')}\nAssistant: {conversation.get('assistant_message', '')}"
            
            memory = Memory(
                content=content,
                metadata={
                    "conversation_id": conversation.get('id'),
                    "model": conversation.get('model', 'gpt-4o'),
                    "temperature": conversation.get('temperature', 0.7)
                },
                timestamp=datetime.now(),
                type="conversation",
                role="both"
            )
            
            # Add to memory engine
            self.memory_engine.add_memory(memory)
            return True
            
        except Exception as e:
            print(f"Error adding conversation to memory: {e}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get memory system statistics"""
        if not self.memory_engine:
            return {"available": False, "error": "Memory system not available"}
        
        try:
            return {
                "available": True,
                "total_memories": len(self.memory_engine.memories),
                "memory_types": self._count_memory_types(),
                "engine_type": type(self.memory_engine).__name__
            }
        except Exception as e:
            return {"available": False, "error": str(e)}
    
    def _count_memory_types(self) -> Dict[str, int]:
        """Count memories by type"""
        if not self.memory_engine:
            return {}
        
        type_counts = {}
        for memory in self.memory_engine.memories:
            memory_type = getattr(memory, 'type', 'unknown')
            type_counts[memory_type] = type_counts.get(memory_type, 0) + 1
        
        return type_counts

# Global memory integration instance
_memory_integration = None

def get_memory_integration() -> MemoryIntegration:
    """Get global memory integration instance"""
    global _memory_integration
    if _memory_integration is None:
        _memory_integration = MemoryIntegration()
    return _memory_integration