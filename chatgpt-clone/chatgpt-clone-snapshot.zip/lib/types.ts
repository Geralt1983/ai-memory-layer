export interface UIMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
  createdAt?: string
}