"""
AI Memory Layer API Module
Provides REST API endpoints for the memory system
"""

__version__ = "1.3.0"
