"""
API Endpoints Package
Modular endpoint definitions for clean separation of concerns
"""