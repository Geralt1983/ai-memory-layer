"""Provider implementations for various embedding services."""

# Provider implementations live here
# Each provider should implement the EmbeddingProvider protocol