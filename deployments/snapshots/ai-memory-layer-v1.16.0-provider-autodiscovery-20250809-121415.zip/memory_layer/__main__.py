"""Allow running memory_layer as a module: python -m memory_layer.cli"""
from .cli import main

if __name__ == "__main__":
    main()