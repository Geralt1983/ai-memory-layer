#!/usr/bin/env python3
import numpy as np

print("numpy imported successfully! Version:", np.__version__)
